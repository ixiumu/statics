jQuery(document).ready(function($){
	$("#ntbox-ori").appendTo("#notification");
	if (($.browser.msie) && ($.browser.version == "6.0")){
		var n = $("#notification");
		$("#ie6").show();
		$(n).slideDown("slow");
	}
	$("#content img").lazyload({
		threshold : 200 , 
		effect : "fadeIn"
	});
	$("#content a img").hover(
		function(){
		$(this).stop().fadeTo('fast',0.5);
		},
		function(){
		$(this).stop().fadeTo('fast',1);
	});
	$(".btn-slide").click(function(){
		var i = $(this).attr("href");
		var n = $("#notification");
		var m = $("#notification .metrobox");
		$(m).hide();
		$("#featured .featured-ads").hide();
		$(i).show();
		$(n).show("slow");
		return false;
	});
	$(".btn-scroll").click(function(){
		var i = $(this).attr("href");
		var c = $(i).offset().top;
		$("html,body").animate({scrollTop:c}, 500);
        return false;
	});
	$(".search-focus").click(function() {
		$(".search-input").focus();
	});
	$(".close").click(function(){
		var n = $("#notification");
		$(n).hide("fast");
		$("#featured .featured-ads").show("slow");
		return false;
	});
	$("#live-slider").click(function(){
		$("#slider").slideToggle();
		return false;
	});
	$('.post a[href$="jpg"],.post a[href$="png"],.post a[href$="gif"]').colorbox({transition:'fade',opacity:0.95,current:""}).hover(function(){
		$(this).append('<div id="cboxZoom"></div>');
		var i = $(this).find("img")
		var ol = i.offset().left + i.width() - 39;
		var ot = i.offset().top;
		$("#cboxZoom").css({left: ol, top: ot});
		return false;
	},
	function(){
		$(this).find("div:last").remove();
	});
	$.getScript("http://www.microsofttranslator.com/ajax/v2/toolkit.ashx?mode=manual&toolbar=thin", function() {
		$("#translatorbtn").click(function(){
			translatePage();
		});
	});
	function translatePage(){Microsoft.Translator.translate(document.body,"zh-CHS", "en");}

	if($("#comments-cmt").length>0){
		$("#commentlist li").each(function() {
			var g = $(this).find("ul.children li .comment-content");
			$(this).find(".comment-reply-link:first").clone().appendTo(g);
		});
		$("#commentlist a.comment-reply-link").click(function(){
			var rename = $(this).parents(".comment-content").find(".comment-author-name").text();
			var reid = '"#comment-' + $(this).parents(".comment-content").find(".comment-id").text() + '"';
			$("#comment").append("&lt;a href=" + reid + "&gt;@" + rename + "&lt;/a&gt;&nbsp;").focus();
		});
		$("#cancel-comment-reply-link").click(function(){
			$("#comment").empty();
		});
	}
	//��˵
	$.getScript('http://static.duoshuo.com/embed.js'); //����embed.js
});
var duoshuoQuery = {"short_name":"yudiu"};
addComment = {
    moveForm: function (d, f, i, c) {
        var m = this,
            a, h = m.I(d),
            b = m.I(i),
            l = m.I("cancel-comment-reply-link"),
            j = m.I("comment_parent"),
            k = m.I("comment_post_ID");
        if (!h || !b || !l || !j) {
            return
        }
        m.respondId = i;
        c = c || false;
        if (!m.I("wp-temp-form-div")) {
            a = document.createElement("div");
            a.id = "wp-temp-form-div";
            a.style.display = "none";
            b.parentNode.insertBefore(a, b)
        }
        h.parentNode.insertBefore(b, h.nextSibling);
        if (k && c) {
            k.value = c
        }
        j.value = f;
        l.style.display = "";
        l.onclick = function () {
            var n = addComment,
                e = n.I("wp-temp-form-div"),
                o = n.I(n.respondId);
            if (!e || !o) {
                return
            }
            n.I("comment_parent").value = "0";
            e.parentNode.insertBefore(o, e);
            e.parentNode.removeChild(e);
            this.style.display = "none";
            this.onclick = null;
            return false
        };
        try {
            m.I("comment").focus()
        } catch(g) {}
        return false
    },
    I: function (a) {
        return document.getElementById(a)
    }
};