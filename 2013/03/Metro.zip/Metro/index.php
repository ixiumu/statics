<?php get_header(); ?>
<div id="content" class="left">
    <?php 
    	//列表页标题
		if ( is_category() )  echo '<div class="post"><div class="keyword post-heading">'.single_cat_title( '', false ).' 分类</div><span class="abs"><p>'.category_description().'</p></span></div>';
		if ( is_tag() )  echo '<div class="post"><div class="keyword post-heading">'.single_tag_title( '', false ).' 标签</div><span class="abs"><p>'.tag_description().'</p></span></div>';
		if ( is_author() )  echo '';
		if ( is_archive() ) {
            if (is_day()) { $archive_title = get_the_date();
            echo '<div class="post"><div class="keyword post-heading">'.$archive_title.' 存档 </div></div>';
            } elseif (is_month()) { $archive_title = get_the_date('F Y');
            echo '<div class="post"><div class="keyword post-heading">'.$archive_title.' 存档 </div></div>';
            } elseif (is_year()) { $archive_title = get_the_date('Y');
            echo '<div class="post"><div class="keyword post-heading">'.$archive_title.' 存档 </div></div>';
            }
        }
    ?>
	<?php while ( have_posts() ) : the_post(); ?>
		<?php get_template_part( 'content', get_post_format() ); ?>
	<?php endwhile; ?>

    <?php
        if(function_exists('pagenavi')) {
            pagenavi('<div class="navigation">','</div>');
        }
    ?>
		
<?php get_template_part( 'ad'); ?>
<?php get_sidebar(); ?>
<?php get_footer(); ?>