<!doctype html>
<html>
<head>
	<meta charset="utf-8" />
	<?php if ( is_home() ) { ?><title><?php bloginfo('name'); ?> - <?php bloginfo('description'); ?></title><?php } ?>
<?php if ( is_search() ) { ?><title>搜索结果 - <?php bloginfo('name'); ?></title><?php } ?>
<?php if ( is_single() ) { ?><title><?php echo trim(wp_title('',0)); ?> - <?php bloginfo('name'); ?></title><?php } ?>
<?php if ( is_page() ) { ?><title><?php echo trim(wp_title('',0)); ?> - <?php bloginfo('name'); ?></title><?php } ?>
<?php if ( is_category() ) { ?><title><?php single_cat_title(); ?> - <?php bloginfo('name'); ?></title><?php } ?>
<?php if ( is_month() ) { ?><title><?php the_time('F'); ?> - <?php bloginfo('name'); ?></title><?php } ?>
<?php if (function_exists('is_tag')) { if ( is_tag() ) { ?><title><?php single_tag_title("", true); ?> - <?php bloginfo('name'); ?></title><?php } ?> <?php } ?>
<?php
if (!function_exists('utf8Substr')) {
 function utf8Substr($str, $from, $len)
 {
     return preg_replace('#^(?:[\x00-\x7F]|[\xC0-\xFF][\x80-\xBF]+){0,'.$from.'}'.
          '((?:[\x00-\x7F]|[\xC0-\xFF][\x80-\xBF]+){0,'.$len.'}).*#s',
          '$1',$str);
 }
}
if ( is_single() ){
    if ($post->post_excerpt) {
        $description  = $post->post_excerpt;
    } else {
   if(preg_match('/<p>(.*)<\/p>/iU',trim(strip_tags($post->post_content,"<p>")),$result)){
    $post_content = $result['1'];
   } else {
    $post_content_r = explode("\n",trim(strip_tags($post->post_content)));
    $post_content = $post_content_r['0'];
   }
         $description = utf8Substr($post_content,0,220);
  }
    $keywords = "";
    $tags = wp_get_post_tags($post->ID);
    foreach ($tags as $tag ) {
        $keywords = $keywords . $tag->name . ",";
    }
}
?>
<?php echo "\n"; ?>
<?php if ( is_single() ) { ?>
<meta name="description" content="<?php echo trim($description); ?>" />
<meta name="keywords" content="<?php echo rtrim($keywords,','); ?>" />
<?php } ?>
<?php if ( is_home() ) { ?>
<meta name="description" content="与您分享最精彩有趣的互联网资讯！！各种搞笑、夸张、牛逼、有意思的视频、音乐、电影、游戏、图片、网络应用、实用软件下载等" />
<?php } ?>
	<link rel="shortcut icon" type="image/ico" href="<?php echo get_option('home'); ?>/favicon.ico"/>
	<link rel="alternate" type="text/html" media="handheld" href="http://m.yudiu.com/" title="Mobile/PDA/iPhone" />
	<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="screen" />
<?php //if ( is_singular() ) wp_enqueue_script( 'comment-reply' ); ?>
<?php wp_head(); ?>
</head>
<body>
<div id="top" class="bing-bg"></div>
<div class="wrapper">
<div id="header">
	<div>
		<div class="logo left">
			<a href="<?php echo get_option('home'); ?>/"><img src="<?php bloginfo('stylesheet_directory'); ?>/images/logo.png" alt="<?php bloginfo('name'); ?>"/></a>
			<br/>
			<small class="version"></small>
		</div>
		<ul class="navs right">
			<li style="background-color:#F56933;"><a href="#feed" class="nav-btn btn-slide block">订阅</a></li> 
			<li style="background-color:#E63B3F;"><a href="http://weibo.com/" target="_blank" class="nav-btn block">微博</a></li> 
		</ul>
		<ul class="nav right">
			<li><a href="<?php echo get_option('home'); ?>/" title="首页">首页</a></li>
			<li><a href="/tag/探索/" title="精彩的科学图片,神奇的未解之谜,关注科学新闻,探索自然奥秘">探索</a></li>
			<li><a href="/tag/体验/" title="使用技巧、内测体验方法、新酷玩法介绍">体验</a></li>
			<li><a href="/tag/创意/" title="新鲜创意资讯聚合、提供创意设计灵感">创意</a></li>
			<li><a href="/tag/图片/" title="各种创意图片及美女图片下载">图片</a></li>
			<li><a href="/tag/视频/" title="网罗最新最热新闻、娱乐视频资讯">视频</a></li>
			<li><a href="/tag/下载/" title="相关软件下载">下载</a></li>
			<li><a href="/about/" title="关于 <?php bloginfo('name'); ?>">关于</a></li>
			<li><a href="#contact" title="爆料、合作或任何问题" class="btn-slide">联系</a></li>
			<li><a href="#search" class="btn-slide controls ti search-focus" style="background-position:16px -17px;" title="搜索">搜索</a></li>
			<li><a href="#" id="translatorbtn" class="controls ti" style="background-position:14px 7px;" onclick="translatePage();return false;" title="translate this page">Translator</a></li>
		</ul>
	</div>
</div>
<div id="featured" class="pr clear">
	<div class="pinned pa panel ti">固顶</div>
	<div class="featured-item left">
		<div class="post-heading">近期热点</div>
		<span class="abs"><?php if (function_exists('get_most_viewed')) get_least_viewed('post', 3); ?>
	</div>
	<div id="notification" class="right hide"></div>
	<div class="ads featured-ads right pr"><div class="ads-tag pa">广告</div>
		<script type="text/javascript"><!--
		google_ad_client = "ca-pub-6470305625680726";
		/* yudiu_468_60 */
		google_ad_slot = "2442445198";
		google_ad_width = 468;
		google_ad_height = 60;
		//-->
		</script>
		<script type="text/javascript"
		src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
	</div>
</div>
<div class="breadcrumb block">
	<div id="slider" class="hide">
		<a href="/tag/build-2012/"><img src="<?php bloginfo('stylesheet_directory'); ?>/images/tiles/build-wide.png" alt="Build 2012"/></a>
		
	</div>
	<div class="path">
		<div class="left"></div>
		<div id="live-slider" class="app-btn large right">...</div>
		<div class="clear"></div>
	</div>
</div>
