	<div class="clear"></div>
	<div id="ntbox-ori">
		<div id="search" class="metrobox pr hide">
			<div class="metroboxt left">搜索</div>
			<div class="ntbox left"><form method="get" class="form-search" name="searchform" action="/index.php">
				<input type="text" class="search-input left" size="24" value="" name="s"/>
				<input type="submit" class="search-submit right fn-ti controls" value=""/>
			</form>
			</div>
			<a href="#" class="btn-close pa nav-btn right close">X</a>
		</div>
		<div id="contact" class="metrobox pr hide">
			<div class="metroboxt left">联系</div>
			<div class="ntbox left">
				<ul class="navs left">
					<li style="background-color:#E63B3F;"><a href="http://weibo.com/" target="_blank" class="slim-btn block">新浪微博</a></li>
					<li style="background-color:#0FA1B8;"><a href="http://www.twitter.com/" target="_blank" class="slim-btn block">Twitter</a></li>
					<li style="background-color:#0354A4;"><a href="mailto:web@yudiu.com" class="slim-btn block">电子邮件</a></li>
				</ul>
			</div>
			<a href="#" class="btn-close pa nav-btn right close">X</a>
		</div>
		<div id="feed" class="metrobox pr hide">
			<div class="metroboxt left">订阅</div>
			<div class="ntbox left">
				<ul class="navs left">
					<li style="background-color:#4285F4;"><a href="http://fusion.google.com/add?feedurl=<?php bloginfo('rss2_url'); ?>" target="_blank" class="slim-btn block">Google</a></li>
					<li style="background-color:#239FDB;"><a href="http://mail.qq.com/cgi-bin/feed?u=<?php bloginfo('rss2_url'); ?>" target="_blank" class="slim-btn block">QQ</a></li>
					<li style="background-color:#EC2126;"><a href="http://reader.youdao.com/#url=<?php bloginfo('rss2_url'); ?>" target="_blank" class="slim-btn block">有道</a></li>
					
					<li style="background-color:#F74419;"><a href="http://www.xianguo.com/subscribe.php?url=<?php bloginfo('rss2_url'); ?>" target="_blank" class="slim-btn block">鲜果</a></li>
					<li style="background-color:#1C8D35;"><a href="http://9.douban.com/reader/subscribe?url=<?php bloginfo('rss2_url'); ?>" target="_blank" class="slim-btn block">豆瓣</a></li>
					<li style="background-color:#666;"><a href="<?php bloginfo('rss2_url'); ?>" target="_blank" class="slim-btn block">…</a></li>
				</ul>
			</div>
			<a href="#" class="btn-close pa nav-btn right close">X</a>
		</div>
		<div id="ie6" class="metrobox pr hide">
			<div class="left">
			<p>您正在使用 IE 6 浏览器访问本博客。简单几步，您就可以升级：<a href="http://windows.microsoft.com/zh-cn/internet-explorer/downloads/ie" target="_blank" rel="nofollow">Internet Explorer</a></p>
			</div>
			<a href="#" class="btn-close pa nav-btn right close">X</a>
		</div>
		<div id="MicrosoftTranslatorWidget" class="hide" style="border-color:#362F2A;background-color:#362F2A;"></div>
	</div>
</div>
<div id="footer" class="clear">
	<div class="legal wrapper">
		<div class="ntbox-1 left">
		<p><a href="/about/">关于</a> <span class="sep">|</span> <a href="/archives/" title="日期归档">归档</a> <span class="sep">|</span> <a href="/about/" title="爆料、合作或任何问题">联系</a> <span class="sep">|</span> <a href="http://wordpress.org/" title="Powered by WordPress" target="_blank">WordPress</a></p>
		<p>&copy; 2007 - 2013 <?php bloginfo('name'); ?> 保留一切权利 <span style="font-family:'Segoe UI Symbol';">&#128151;</span></p>
				</div>
		<div class="right"><p><a href="<?php echo get_option('home'); ?>/wp-login.php">登录</a> </p></div>
	</div>
</div>
<!--/livesino -->
<script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.4.4/jquery.min.js"></script>
<script type="text/javascript" src="<?php bloginfo('stylesheet_directory'); ?>/core/lazy.min.js"></script>
<script type="text/javascript" src="<?php bloginfo('stylesheet_directory'); ?>/core/jquery.colorbox.js"></script>
<script type="text/javascript" src="<?php bloginfo('stylesheet_directory'); ?>/core/app.js"></script>
<?php wp_footer(); ?>
<script type="text/javascript">
  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-8195328-9']);
  _gaq.push(['_trackPageview']);
  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
</script>
</body>
</html>