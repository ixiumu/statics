<?php get_header(); ?>

<div id="content" class="left">
<?php 
    if (have_posts()) : while (have_posts()) : the_post();
        /**
         * Find the post formatting for the single post (full post view) in the post-single.php file
         */
        get_template_part('content', 'single');
    endwhile;
    
    else :
        get_template_part('content', 'none');
    endif; 
?>

<?php get_sidebar(); ?>

<?php get_footer(); ?>