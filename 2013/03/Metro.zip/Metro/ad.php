	<div class="ads post-ads right pr"><div class="ads-tag pa">广告</div>
		<script type="text/javascript"><!--
		google_ad_client = "ca-pub-6470305625680726";
		/* yudiu_468_60 */
		google_ad_slot = "2442445198";
		google_ad_width = 468;
		google_ad_height = 60;
		//-->
		</script>
		<script type="text/javascript"
		src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
	</div></div>