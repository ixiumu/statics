<?php
remove_action('wp_head', 'wp_generator');//移除版本信息
remove_action('wp_head', 'rsd_link');//禁用远程撰写
remove_action('wp_head', 'wlwmanifest_link');//禁用LIVE 撰写
remove_action('wp_head', 'wp_shortlink_wp_head', 10, 0 );//禁用短网址
remove_action('wp_head', 'feed_links_extra', 3);//禁用内页FEED
remove_action('wp_head', 'adjacent_posts_rel_link_wp_head', 10, 0 );//禁用上下篇
remove_action('wp_head', 'rel_canonical');//禁用上下篇

remove_action('wp_print_styles', 'wp_syntax_style');//去掉wp-syntax样式

//禁用多说
remove_action( 'wp_head', 'wp_print_scripts' );
remove_action( 'wp_head', 'wp_print_head_scripts', 9 );
remove_action( 'wp_head', 'wp_enqueue_scripts', 1 );
//add_action( 'wp_footer', 'wp_print_scripts', 5 );
//add_action( 'wp_footer', 'wp_enqueue_scripts', 5 );
//add_action( 'wp_footer', 'wp_print_head_scripts', 5 );
/*
//修改JQ库
if( !is_admin()){
	wp_deregister_script('jquery');
	wp_register_script('jquery', ("//lib.sinaapp.com/js/jquery/1.8.3/jquery.min.js"), false, '1.8.2');
	//wp_register_script('jquery', ("http://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"), false, '1.7.2');
	wp_enqueue_script('jquery');
}

//JQ放底部
function wpjam_load_jquery_in_footer( &$scripts) {
	if ( ! is_admin() )
		$scripts->add_data( 'jquery', 'group', 1 );
}
add_action( 'wp_default_scripts', 'wpjam_load_jquery_in_footer' );
*/
//移除登陆框 Logo 的连接地址
function the_url( $url ) {
    return get_bloginfo( 'url' );
}
add_filter( 'login_headerurl', 'the_url' );

//禁止自动保存草稿和修订版本
remove_action('pre_post_update', 'wp_save_post_revision' );
add_action( 'wp_print_scripts', 'disable_autosave' );
function disable_autosave() {
wp_deregister_script('autosave');
}

/*
//新窗口打开评论里的链接
function remove_comment_links() {
global $comment;
$url = get_comment_author_url();
$author = get_comment_author();
if ( empty( $url ) || 'http://' == $url )
$return = $author;
else
$return = "<a href='$url' rel='external nofollow' target='_blank'>$author</a>";
return $return;
}
add_filter('get_comment_author_link', 'remove_comment_links');
remove_filter('comment_text', 'make_clickable', 9);

//注册侧边栏小工具
if( function_exists('register_sidebar') ) {
	register_sidebar(array(
	'name' => '侧边栏',
	'id' => 'sidebar_primary',
	'before_widget' => '<ul class="widget-container"><li id="%1$s" class="widget %2$s">', // widget 的开始标签
	'after_widget' => '</li></ul>', // widget 的结束标签
	'before_title' => '<h3 class="widgettitle">', // 标题的开始标签
	'after_title' => '</h3>' // 标题的结束标签
	));
}
*/
//支持特征图片功能
add_theme_support('post-thumbnails');

//注册自定义菜单
if (function_exists('register_nav_menus')) {
    register_nav_menus(
        array(
            'secondary' => '主导航栏',
        )
    );
}

//摘要截取函数
function excerpt($limit) { 
	$excerpt = explode(' ', get_the_excerpt(), $limit); 
	if (count($excerpt)>=$limit) { 
	array_pop($excerpt); 
	$excerpt = implode(" ",$excerpt).'...'; 
	} else { 
	$excerpt = implode(" ",$excerpt); 
	} 
	$excerpt = preg_replace('`\[[^\]]*\]`','',$excerpt); 
	return $excerpt; 
}
//阅读全文链接加P
function my_more_link($more_link) { 
	return  '<p>'.$more_link.'</p>';
}
add_filter('the_content_more_link', 'my_more_link', 10, 2); 

function my_excerpt_more($more) {
	return '...';
}
add_filter('excerpt_more', 'my_excerpt_more');


/* Pagenavi */  
function pagenavi( $before = '', $after = '', $p = 3 ) {
	if ( is_singular() ) return;
	global $wp_query, $paged;
	$max_page = $wp_query->max_num_pages;
	if ( $max_page == 1 ) return;
	if ( empty( $paged ) ) $paged = 1;
	echo $before.'<div class="page_navi">'."\n";
	//echo '<span class="pages">Page: ' . $paged . ' of ' . $max_page . ' </span>';
	if ( $paged > 1 ) p_link( $paged - 1, '上一页', '<' );
	if ( $paged > $p + 1 ) p_link( 1, '首页' );
	if ( $paged > $p + 2 ) echo '... ';
	for( $i = $paged - $p; $i <= $paged + $p; $i++ ) {
		if ( $i > 0 && $i <= $max_page ) $i == $paged ? print '<span class="page-numbers current">'.$i.'</span>' : p_link( $i );
	}
	if ( $paged < $max_page - $p - 1 ) echo '... ';
	if ( $paged < $max_page - $p ) p_link( $max_page, '最后一页' );
	if ( $paged < $max_page ) p_link( $paged + 1,'下一页', '>' );
	echo '</div>'.$after."\n";
}   
function p_link( $i, $title = '', $linktype = '' ) {
	if ( $title == '' ) $title = "第{$i}页";   
	if ( $linktype == '' ) { $linktext = $i; } else { $linktext = $linktype; }
	echo '<a class="page-numbers" href="', esc_html( get_pagenum_link( $i ) ), '" title="'.$title.'">'.$linktext.'</a>';
}