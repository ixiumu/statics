<?php get_header(); ?>
<div id="content" class="left">
	<div class="post"><div class="keyword post-heading"><?php echo get_search_query(); ?> 搜索结果</div><span class="abs"><a href="#search" class="btn-slide search-focus">更换关键词搜索</a></span></div>
	<?php while ( have_posts() ) : the_post(); ?>
		<?php get_template_part( 'content', get_post_format() ); ?>
	<?php endwhile; ?>
	
    <?php
        if(function_exists('pagenavi')) {
            pagenavi('<div class="navigation">','</div>');
        }
    ?>
    
<?php get_template_part( 'ad'); ?>
<?php get_sidebar(); ?>
<?php get_footer(); ?>