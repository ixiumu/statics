		<div class="post" id="post-<?php the_ID(); ?>">
		<div class="entry-head clear"><h2 class="left"><a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2><div class="post-cmt block pr right"><a href="<?php the_permalink(); ?>#respond" title="《<?php the_title(); ?>》上的评论"><span class="ds-thread-count" data-thread-key="<?php the_ID(); ?>" data-replace="1">0</span></a><span class="corner pa"></span></div></div>
		<div class="entry clear">
			<span class="post-meta"><?php echo date("Y年m月d日 H:i:s",get_the_time('U')); ?> - <?php the_author(); ?> <?php if(is_user_logged_in()) edit_post_link();?> </span>
			<span class="post-love"></span>
            <?php
                the_content('');
            ?>
		</div>
		<!-- Baidu Button BEGIN -->
		<div id="bdshare" class="bdshare_t bds_tools_32 get-codes-bdshare">
			<a class="bds_tsina"></a>
			<a class="bds_qzone"></a>
			<a class="bds_tqq"></a>
			<a class="bds_renren"></a>
			<span class="bds_more">更多</span>
				<a class="shareCount"></a>
			</div>
		<script type="text/javascript" id="bdshare_js" data="type=tools&amp;uid=702471"></script>
		<script type="text/javascript" id="bdshell_js"></script>
		<script type="text/javascript">document.getElementById("bdshell_js").src="http://share.baidu.com/static/js/shell_v2.js?cdnversion="+new Date().getHours();</script>
		<!-- Baidu Button END -->
	</div>
			<a name="comments"></a>
    <?php
        if(comments_open( get_the_ID() ))  {
            comments_template('', true); 
        }
    ?>