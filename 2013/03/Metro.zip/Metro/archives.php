<?php
/**
 * @package WordPress
 * @subpackage Default_Theme
 */
/*
Template Name: Archives
*/
?>
<?php get_header(); ?>

<div id="sidebar" class="left">
	<div class="sidebar-widget">
		<div class="sidebar-div">
			<h4 class="sidebar-title">存档</h4>
			<select name="archive-dropdown" onchange="document.location.href=this.options[this.selectedIndex].value;">
				<option>全部存档</option>
				<?php wp_get_archives("format=option&show_post_count=true"); ?>
			</select>
		</div>
	</div>
</div>
<div id="content" class="right">
	<div class="post" id="post-<?php the_ID(); ?>">
		<div class="entry">
			<div class="archive-tiles">
<?php //wp_get_archives('before=html&show_post_count=true'); 

function archives_list_SHe() {
     global $wpdb,$month;
     $lastpost = $wpdb->get_var("SELECT ID FROM $wpdb->posts WHERE post_date <'" . current_time('mysql') . "' AND post_status='publish' AND post_type='post' AND post_password='' ORDER BY post_date DESC LIMIT 1");
     //$output = get_option('SHe_archives_'.$lastpost);
     if(empty($output)){
         $output = '';
         $wpdb->query("DELETE FROM $wpdb->options WHERE option_name LIKE 'SHe_archives_%'");
         $q = "SELECT DISTINCT YEAR(post_date) AS year, MONTH(post_date) AS month, count(ID) as posts FROM $wpdb->posts p WHERE post_date <'" . current_time('mysql') . "' AND post_status='publish' AND post_type='post' AND post_password='' GROUP BY YEAR(post_date), MONTH(post_date) ORDER BY post_date DESC";
         $monthresults = $wpdb->get_results($q);
         if ($monthresults) {
             foreach ($monthresults as $monthresult) {
             $thismonth    = zeroise($monthresult->month, 2);
             $thisyear    = $monthresult->year;
             $q = "SELECT ID FROM $wpdb->posts p WHERE post_date LIKE '$thisyear-$thismonth-%' AND post_date AND post_status='publish' AND post_type='post' AND post_password='' ORDER BY post_date DESC";
             $postresults = $wpdb->get_results($q);
             if ($postresults) {
                 $text = sprintf('%s %d', $month[zeroise($monthresult->month,2)], $monthresult->year);
                 $text1 = sprintf('%s', $month[zeroise($monthresult->month,2)], $monthresult->year);
                 $postcount = count($postresults);
                 $output .= '<a href="/'.$monthresult->year.'/'.zeroise($monthresult->month,2).'/" title="' . $text . ' 存档 - 文章数 '.count($postresults).'" class="tiles block"><span class="year block">' . $monthresult->year . '</span><span class="year block large">' . $text1 . '</span><span class="num block">'.count($postresults).'</span></a>' . "\n";
             }
             $output .= '</ul></li></ul>' . "\n";
             }
         update_option('SHe_archives_'.$lastpost,$output);
         }else{
             $output = '<div class="errorbox">Sorry, no posts matched your criteria.</div>' . "\n";
         }
     }
     echo $output;
 }
archives_list_SHe();
//wp_get_archives('type=monthly&format=custom&before=a&after=b&show_post_count=1');
	?>

</div>
		</div>
	</div>
<?php get_template_part( 'ad'); ?>
<?php get_footer(); ?>