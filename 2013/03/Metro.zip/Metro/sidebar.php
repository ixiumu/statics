<div id="sidebar" class="right">
	<div class="sidebar-widget">
		<a href="/tag/体验/"><img src="<?php bloginfo('stylesheet_directory'); ?>/images/tiles/windows-8.png" alt="Windows 8"/></a>
		<a href="/tag/探索/"><img src="<?php bloginfo('stylesheet_directory'); ?>/images/tiles/surface-pro.png" alt="Surface Pro"/></a>
	</div>
<?php if (is_single()) { ?>
	<div class="sidebar-widget">
		<div class="sidebar-div block">
			<h4 class="sidebar-title">相关文章</h4>
		</div>
		<div id="wumiiDisplayDiv"></div>
	</div>
<?php }?>
	<div class="sidebar-widget">
		<div class="sidebar-div block">
			<h4 class="sidebar-title">最新文章</h4>
		</div>
		<ul class="sidebar-list">
			<?php get_archives('postbypost', 9); ?>
		</ul>
	</div>
<?php if (is_home()) { ?>
	<div class="sidebar-widget">
		<div class="sidebar-div block">
			<h4 class="sidebar-title">最新评论</h4>
		</div>
		<ul class="ds-recent-comments" data-num-items="10" data-show-avatars="1" data-show-time="1" data-show-title="0" data-show-admin="1" data-excerpt-length="70"></ul>
		<script>if(typeof DUOSHUO!=='undefined')
DUOSHUO.RecentVisitors('.ds-recent-visitors');</script>
	</div>
<?php }?>
	<div class="sidebar-widget">
		<div class="sidebar-div block">
			<h4 class="sidebar-title">存档</h4>
			<select name="archive-dropdown" onchange="document.location.href=this.options[this.selectedIndex].value;">
			<?php wp_get_archives("format=option&show_post_count=true"); ?> 
			<option value="/archives/">全部存档</option>
			</select>
		</div>
	</div>
<?php if (is_home()) { ?>
		<div class="sidebar-widget">
			<div class="sidebar-div block">
				<h4 class="sidebar-title">链接</h4>
			</div>
			<ul class="sidebar-list">
				<?php wp_list_bookmarks('orderby=id&categorize=0&category=2&show_images=0&title_li=');?>
			</ul>
		</div>
<?php
}
    ?>
		<div class="sidebar-widget">
		<div class="ads sidebar-ads pr"><div class="ads-tag pa">广告</div>
			<script type="text/javascript"><!--
			google_ad_client = "ca-pub-6470305625680726";
			/* yudiu_160_600 */
			google_ad_slot = "3999903597";
			google_ad_width = 160;
			google_ad_height = 600;
			//-->
			</script>
			<script type="text/javascript"
			src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
			</script>
		</div>
		<?php /*div class="sidebar-adsense">
						<span id="c56972">
				<table cellspacing="0" cellpadding="0" style="width:100%; height:100%; border:0 none #000000;">
					<tr>
						<td>
							<a href="http://www.sportsbook.ag">NBA Basketball Betting</a> - nba basketball betting			</td>
					</tr>
				</table>
			</span>
					</div */?>
	</div>
	<div class="sidebar-widget">
		<div class="sidebar-div block"><a href="#top" class="btn-scroll"><h4 class="sidebar-title"><strong>&#8743;</strong> 返回顶部</h4></a></div>
	</div>
</div>
<!--/sidebar -->