<?php get_header(); ?>

<div id="page">
            <?php 
                if (have_posts()) : while (have_posts()) : the_post();
                    get_template_part('content', 'page');
                endwhile;
                
                else :
                    get_template_part('content', 'none');
                endif; 
            ?>

	<?php get_template_part( 'ad'); ?>

<?php get_footer(); ?>