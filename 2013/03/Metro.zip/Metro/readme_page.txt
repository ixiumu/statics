<!doctype html>
<html>
<head>
	<meta charset="utf-8"/>
	<meta name="msapplication-task" content="name=LiveSino 新浪微博;action-uri=http://weibo.com/picturepan2;icon-uri=wp-content/themes/thea/icons/sinat.ico"/>
	<meta name="msapplication-task" content="name=LiveSino Twitter;action-uri=http://twitter.com/picturepan2;icon-uri=wp-content/themes/thea/icons/twitter.ico"/>
	<meta name="msapplication-task" content="name=LiveSino RSS 订阅;action-uri=http://feed.livesino.net;icon-uri=wp-content/themes/thea/icons/rss.ico"/>
	<title>关于 LiveSino | LiveSino 中文版</title>
	<link rel="shortcut icon" type="image/ico" href="http://livesino.net/fav.ico"/>
	<link rel="alternate" type="text/html" media="handheld" href="http://m.livesino.net" title="Mobile/PDA/iPhone"/>
	<link rel="alternate" type="application/rss+xml" title="RSS 2.0" href="http://feed.livesino.net"/>
	<link rel="alternate" type="application/atom+xml" title="Atom 0.3" href="http://livesino.net/feed/atom"/>
	<link rel="pingback" href="http://livesino.net/xmlrpc.php"/>
	<link rel="stylesheet" type="text/css" media="all" href="/wp-content/themes/thea/style.css"/>
	<script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.4.4/jquery.min.js"></script>
	<script type="text/javascript" src="/wp-content/themes/thea/core/lazy.min.js"></script>
	<script type="text/javascript" src="/wp-content/themes/thea/core/app.js"></script>
	<script type="text/javascript">var duoshuoQuery={"short_name":"livesino","sso":{"login":"http:\/\/livesino.net\/wp-login.php?action=duoshuo_login","logout":"http:\/\/livesino.net\/wp-login.php?action=logout&_wpnonce=ef787dca58"},"remote_auth":"W10= 107f1cf2ca616beb35a7a265c6f8ebfc4827f3d3 1362463324"};duoshuoQuery.sso.login+='&redirect_to='+encodeURIComponent(window.location.href);duoshuoQuery.sso.logout+='&redirect_to='+encodeURIComponent(window.location.href);</script>
<script type='text/javascript' src='http://static.duoshuo.com/embed.js'></script>
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://livesino.net/xmlrpc.php?rsd"/>
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://livesino.net/wp-includes/wlwmanifest.xml"/> 
<link rel='next' title='KB' href='http://livesino.net/kb'/>
<link rel='canonical' href='http://livesino.net/about'/>
<meta name="keywords" content="关于 LiveSino"/>
<meta name="description" content="LiveSino（livesino.net）是一个专注于报道微软及其相关产品和技术的资讯博客。    	成立于 2007 年 3 月 1 日  	通过 Wordpress 构建，主题为 Theme Codename H，目前运行于美国的 Linode 服"/>
</head>
<body>
<div id="top" class="bing-bg"></div>
<div class="wrapper">
<div id="header">
	<div>
		<div class="logo left">
			<a href="/"><img src="/wp-content/themes/thea/images/livesino-logo.png" alt="权威微软(Microsoft)博客"/></a>
			<br/>
			<small class="version"></small>
		</div>
		<ul class="navs right">
			<li style="background-color:#F56933;"><a href="#feed" class="nav-btn btn-slide block">订阅</a></li> 
			<li style="background-color:#E63B3F;"><a href="http://weibo.com/livesino" target="_blank" class="nav-btn block">微博</a></li> 
		</ul>
		<ul class="nav right">
			<li><a href="/category/news" title="微软产品和技术的资讯、新闻、更新信息介绍">资讯</a></li>
			<li><a href="/category/experience" title="微软产品专业体验、评测、使用报告">体验</a></li>
			<li><a href="/category/opinion" title="关于微软相关的产品想法、观点、评论">观点</a></li>
			<li><a href="/category/atlive" title="使用技巧、内测体验方法、新酷玩法介绍">技巧</a></li>
			<li><a href="/category/dev" title="微软开发工具、框架、API、开发包相关内容">开发</a></li>
			<li><a href="/category/video" title="微软产品专业演示视频、视频介绍、屏幕录制视频等">视频</a></li>
			<li><a href="/category/download" title="微软产品相关下载">下载</a></li>
			<li><a href="/about" title="关于 LiveSino">关于</a></li>
			<li><a href="#contact" title="爆料、合作或任何问题" class="btn-slide">联系</a></li>
			<li><a href="#search" class="btn-slide controls ti search-focus" style="background-position:16px -17px;" title="搜索">搜索</a></li>
			<li><a href="#" id="translatorbtn" class="controls ti" style="background-position:14px 7px;" onclick="translatePage();" title="translate this page">Translator</a></li>
		</ul>
	</div>
</div>
<div id="featured" class="pr clear">
	<div class="pinned pa panel ti">固顶</div>
	<div class="featured-item left">
		<div class="post-heading">近期热点</div>
		<span class="abs"><a href="/archives/5084.live" title="Office 2013/Office 365 家庭高级版发布" style="color:#666;">Office 2013/Office 365 家庭高级版发布</a> | <a href="/archives/5014.live" title="Surface Pro 初体验" style="color:#666;">Surface Pro 将于 2 月 9 日上市</span> | <a href="/archives/5084.live" title="Windows Phone 7.8 更新推送" style="color:#666;">Windows Phone 7.8 更新推送</a>
	</div>
	<div id="notification" class="right hide"></div>
	<div class="ads featured-ads right pr"><div class="ads-tag pa">广告</div>
		<script type="text/javascript">google_ad_client="ca-pub-2225124559530218";google_ad_slot="4113597124";google_ad_width=468;google_ad_height=60;</script>
		<script type="text/javascript" src="http://pagead2.googlesyndication.com/pagead/show_ads.js"></script>
	</div>
</div>
<div class="breadcrumb block">
	<div id="slider" class="hide">
		<a href="/tag/build-2012/"><img src="/wp-content/themes/thea/images/tiles/build-wide.png" alt="Build 2012"/></a>
		
	</div>
	<div class="path">
		<div class="left"></div>
		<div id="live-slider" class="app-btn large right">...</div>
		<div class="clear"></div>
	</div>
</div><div id="page">
			<div class="post" id="post-2">
		<div class="entry-head clear"><h2 class="left"><a href="http://livesino.net/about" rel="bookmark" title="关于 LiveSino">关于 LiveSino</a></h2><div class="post-cmt block pr right"><a href="http://livesino.net/about#comments" title="《关于 LiveSino》上的评论"><span class="ds-thread-count" data-thread-key="2" data-replace="1">28</span></a><span class="corner pa"></span></div></div>
		<div class="entry">
			<span class="post-meta">2007 年 5 月 12 日,  8:47 下午 - Picturepan2 </span>
			<p>LiveSino（livesino.net）是一个专注于报道微软及其相关产品和技术的资讯博客。</p>
<ul>
<li>成立于 2007 年 3 月 1 日</li>
<li>通过 WordPress 构建，主题为 <a href="http://livesino.net/theme-codename-h">Theme Codename H</a>，目前运行于美国的 Linode 服务器上</li>
</ul>
<h4>原则</h4>
<p>1 ) 我们因兴趣而写：我们很乐意和大家分享我们所了解的信息。</p>
<p>2 ) 我们做的不仅仅是翻译：尽管微软有很多官方的博客了，但我们也有独特的价值。</p>
<p>3 ) 我们努力在第一时间发布信息：我们只能说尽力做到在第一时间发布有价值的信息，不保证每次都能。</p>
<p>4 ) 我们不会破坏 NDA 保密协议：我们尊重微软，并坚持我们的原则。尽管我们有获得信息的渠道，也经常爆料，但我们会根据 NDA 保密协议来决定。</p>
<p>5 ) 我们通常会谨慎对待确切的产品发布日期，因为微软的产品常常推迟发布。</p>
<p>6 ) 我们也会犯错误：但我们尽量保证信息的准确性，并且我们为我们所写负责。</p>
<p>7 ) 我们会涉及所有内容，也包括超级机密项目：我们是站在读者感兴趣的立场上的，但也不会因此损害微软的利益。我们遵守第四条。</p>
<p>8 ) 我们不代表微软官方：LiveSino 是非微软官方博客，我们的观点和评论都出于个人。</p>
<p>联系：picturepan2 -at- hotmail.com</p>
		</div>
		<!-- Baidu Button BEGIN -->
		<div id="bdshare" class="bdshare_t bds_tools_32 get-codes-bdshare">
			<a class="bds_tsina"></a>
			<a class="bds_qzone"></a>
			<a class="bds_tqq"></a>
			<a class="bds_renren"></a>
			<span class="bds_more">更多</span>
				<a class="shareCount"></a>
			</div>
		<script type="text/javascript" id="bdshare_js" data="type=tools&amp;uid=702471"></script>
		<script type="text/javascript" id="bdshell_js"></script>
		<script type="text/javascript">document.getElementById("bdshell_js").src="http://share.baidu.com/static/js/shell_v2.js?cdnversion="+new Date().getHours();</script>
		<!-- Baidu Button END -->
	</div>
	<a name="comments"></a>

<div class="ds-thread" data-thread-key="2" data-author-key="1" data-title="关于 LiveSino" data-url="http://livesino.net/about"></div>

<script type="text/javascript">if(typeof DUOSHUO!=='undefined')
DUOSHUO.EmbedThread('.ds-thread');</script>
	<div id="ds-ssr">

		
            <ol id="commentlist">
                		<li class="post pingback">
			<p>Pingback: <a href='http://www.mcgeek.cn/archives/330.geek' rel='external nofollow' class='url'>超思维机械境&raquo; Blog 存档 &raquo; Feedsky首页展示LiveSino</a></p>
		</li>
		<li class="post pingback">
			<p>Pingback: <a href='http://www.ktmoy.com/archives/169' rel='external nofollow' class='url'>Theme Codename H 正式推出 - IT菜园</a></p>
		</li>
		<li class="comment even thread-even depth-1" id="li-comment-37823">
			<article id="comment-37823" class="comment">
				<footer class="comment-meta">
					<cite class="comment-author vcard">
						<span class="fn"><a href='http://www.phonebeta.com' rel='external nofollow' class='url'>PhoneBeta</a></span> on <a rel="nofollow" href="http://livesino.net/about#comment-37823"><time pubdate datetime="2011-01-28T15:44:21+00:00">2011 年 01 月 28 日 at 3:44 下午</time></a> <span class="says">said:</span>					</cite><!-- .comment-author .vcard -->
				</footer>
	
				<div class="comment-content"><p>你好，我是Windows Phone 7中文论坛|机智网的友情链接工作人员，你的网站做的很专业，希望能做的越来越好。<br/>
机智网希望能够跟贵站交换友情链接。<br/>
网站名称：机智网<br/>
网站地址：www.phonebeta.com<br/>
本站已经做好贵站的友情链接。<br/>
最后祝愿贵站办的越来越好！</p>
</div>
				
			</article><!-- #comment-## -->
		</li>
		<li class="comment odd alt thread-odd thread-alt depth-1" id="li-comment-38662">
			<article id="comment-38662" class="comment">
				<footer class="comment-meta">
					<cite class="comment-author vcard">
						<span class="fn"><a href='http://zou.lu/' rel='external nofollow' class='url'>Showfom</a></span> on <a rel="nofollow" href="http://livesino.net/about#comment-38662"><time pubdate datetime="2011-03-19T20:43:55+00:00">2011 年 03 月 19 日 at 8:43 下午</time></a> <span class="says">said:</span>					</cite><!-- .comment-author .vcard -->
				</footer>
	
				<div class="comment-content"><p>投稿</p>
<p>《我们是IE家族》</p>
<p>从IE2到IE9的介绍视频</p>
<p><a href="http://v.youku.com/v_show/id_XMjUyMDU3MjY4.html" rel="nofollow">http://v.youku.com/v_show/id_XMjUyMDU3MjY4.html</a></p>
<p>能带个链接更好 呼呼 <a href="http://luo.bo/5982/" rel="nofollow">http://luo.bo/5982/</a></p>
</div>
				
			</article><!-- #comment-## -->
		<ul class='children'>
		<li class="comment even depth-2" id="li-comment-39401">
			<article id="comment-39401" class="comment">
				<footer class="comment-meta">
					<cite class="comment-author vcard">
						<span class="fn">淡如水</span> on <a rel="nofollow" href="http://livesino.net/about#comment-39401"><time pubdate datetime="2011-05-03T15:27:57+00:00">2011 年 05 月 3 日 at 3:27 下午</time></a> <span class="says">said:</span>					</cite><!-- .comment-author .vcard -->
				</footer>
	
				<div class="comment-content"><p>您好，我是网易商务经理，顾萌轲，我们新上线了一个rss订阅平台，希望能够与贵网站进行内容方面的合作，请问您方便加一下qq吗，方便联系，谢谢，我的qq是353863262，邮箱是gumengke@corp.netease.com</p>
</div>
				
			</article><!-- #comment-## -->
		</li>
</ul>
</li>
		<li class="comment odd alt thread-even depth-1" id="li-comment-39168">
			<article id="comment-39168" class="comment">
				<footer class="comment-meta">
					<cite class="comment-author vcard">
						<span class="fn"><a href='http://www.imsl.tk' rel='external nofollow' class='url'>淡定</a></span> on <a rel="nofollow" href="http://livesino.net/about#comment-39168"><time pubdate datetime="2011-04-17T13:12:37+00:00">2011 年 04 月 17 日 at 1:12 下午</time></a> <span class="says">said:</span>					</cite><!-- .comment-author .vcard -->
				</footer>
	
				<div class="comment-content"><p>你好，我的博客刚安装了你的主题Theme Codename H ，个人非常喜欢。。。可是有遇到点问题   就是我新建的页面不知道为什么在主页上显示不出来，前边已经建了5个了    很正常     能帮我解答一下吗    ？</p>
</div>
				
			</article><!-- #comment-## -->
		<ul class='children'>
		<li class="comment byuser comment-author-picturepan2 bypostauthor even depth-2" id="li-comment-39170">
			<article id="comment-39170" class="comment">
				<footer class="comment-meta">
					<cite class="comment-author vcard">
						<span class="fn"><a href='http://livesino.net' rel='external nofollow' class='url'>Picturepan2</a></span> on <a rel="nofollow" href="http://livesino.net/about#comment-39170"><time pubdate datetime="2011-04-17T17:40:15+00:00">2011 年 04 月 17 日 at 5:40 下午</time></a> <span class="says">said:</span>					</cite><!-- .comment-author .vcard -->
				</footer>
	
				<div class="comment-content"><p><a href="#comment-39168" rel="nofollow">@淡定</a> 本来就显示不出来的。</p>
</div>
				
			</article><!-- #comment-## -->
		</li>
</ul>
</li>
		<li class="comment odd alt thread-odd thread-alt depth-1" id="li-comment-39446">
			<article id="comment-39446" class="comment">
				<footer class="comment-meta">
					<cite class="comment-author vcard">
						<span class="fn">淡如水</span> on <a rel="nofollow" href="http://livesino.net/about#comment-39446"><time pubdate datetime="2011-05-06T15:32:43+00:00">2011 年 05 月 6 日 at 3:32 下午</time></a> <span class="says">said:</span>					</cite><!-- .comment-author .vcard -->
				</footer>
	
				<div class="comment-content"><p>您好，我是网易商务经理，顾萌轲，我们新上线了一个rss订阅平台，希望能够与贵网站进行内容方面的合作，请问您方便加一下qq吗，方便联系，谢谢，我的qq是353863262，邮箱是gumengke@corp.netease.com，之前一直没收到您的消息，可能是您没看到我之前的留言，所以再发一次，希望能够和您取得联系</p>
</div>
				
			</article><!-- #comment-## -->
		<ul class='children'>
		<li class="comment even depth-2" id="li-comment-45577">
			<article id="comment-45577" class="comment">
				<footer class="comment-meta">
					<cite class="comment-author vcard">
						<span class="fn"><a href='http://www.mediafed.com' rel='external nofollow' class='url'>Dan Kou</a></span> on <a rel="nofollow" href="http://livesino.net/about#comment-45577"><time pubdate datetime="2012-02-16T23:19:28+00:00">2012 年 02 月 16 日 at 11:19 下午</time></a> <span class="says">said:</span>					</cite><!-- .comment-author .vcard -->
				</footer>
	
				<div class="comment-content"><p>你好，我们是做ＲＳＳ广告的服务商。请问怎么联系？　谈谈广告合作的事</p>
</div>
				
			</article><!-- #comment-## -->
		</li>
</ul>
</li>
		<li class="comment odd alt thread-even depth-1" id="li-comment-39796">
			<article id="comment-39796" class="comment">
				<footer class="comment-meta">
					<cite class="comment-author vcard">
						<span class="fn"><a href='http://baixiaosheng.net' rel='external nofollow' class='url'>百晓生</a></span> on <a rel="nofollow" href="http://livesino.net/about#comment-39796"><time pubdate datetime="2011-06-08T03:57:46+00:00">2011 年 06 月 8 日 at 3:57 上午</time></a> <span class="says">said:</span>					</cite><!-- .comment-author .vcard -->
				</footer>
	
				<div class="comment-content"><p>同样出于兴趣，我于今年正式搭建了 淘宝爱好者博客——百晓生（Baixiaosheng.net)，专注于淘宝的产品、动态、文化等淘元素的记录与探讨。想与贵站交换链接，相互学习。</p>
</div>
				
			</article><!-- #comment-## -->
		</li>
		<li class="comment even thread-odd thread-alt depth-1" id="li-comment-40048">
			<article id="comment-40048" class="comment">
				<footer class="comment-meta">
					<cite class="comment-author vcard">
						<span class="fn">Jamie Ton</span> on <a rel="nofollow" href="http://livesino.net/about#comment-40048"><time pubdate datetime="2011-06-28T14:36:06+00:00">2011 年 06 月 28 日 at 2:36 下午</time></a> <span class="says">said:</span>					</cite><!-- .comment-author .vcard -->
				</footer>
	
				<div class="comment-content"><p>Hello,</p>
<p>How can I buy text link ads on your site?</p>
<p>Thank you</p>
</div>
				
			</article><!-- #comment-## -->
		</li>
		<li class="comment odd alt thread-even depth-1" id="li-comment-42370">
			<article id="comment-42370" class="comment">
				<footer class="comment-meta">
					<cite class="comment-author vcard">
						<span class="fn"><a href='http://yunol.net' rel='external nofollow' class='url'>小鱼头</a></span> on <a rel="nofollow" href="http://livesino.net/about#comment-42370"><time pubdate datetime="2011-09-24T05:35:48+00:00">2011 年 09 月 24 日 at 5:35 上午</time></a> <span class="says">said:</span>					</cite><!-- .comment-author .vcard -->
				</footer>
	
				<div class="comment-content"><p>话说我曾经来过。</p>
</div>
				
			</article><!-- #comment-## -->
		</li>
		<li class="comment even thread-odd thread-alt depth-1" id="li-comment-43058">
			<article id="comment-43058" class="comment">
				<footer class="comment-meta">
					<cite class="comment-author vcard">
						<span class="fn"><a href='http://tuxhome.cublog.cn' rel='external nofollow' class='url'>Phnix</a></span> on <a rel="nofollow" href="http://livesino.net/about#comment-43058"><time pubdate datetime="2011-10-19T09:43:25+00:00">2011 年 10 月 19 日 at 9:43 上午</time></a> <span class="says">said:</span>					</cite><!-- .comment-author .vcard -->
				</footer>
	
				<div class="comment-content"><p>突然发现这么个网站，不错。<br/>
window下的开发人员，得对windows的动向有个大概的了解。。</p>
</div>
				
			</article><!-- #comment-## -->
		</li>
		<li class="comment odd alt thread-even depth-1" id="li-comment-43883">
			<article id="comment-43883" class="comment">
				<footer class="comment-meta">
					<cite class="comment-author vcard">
						<span class="fn"><a href='http://www.cndig.org' rel='external nofollow' class='url'>cndig</a></span> on <a rel="nofollow" href="http://livesino.net/about#comment-43883"><time pubdate datetime="2011-11-15T17:55:56+00:00">2011 年 11 月 15 日 at 5:55 下午</time></a> <span class="says">said:</span>					</cite><!-- .comment-author .vcard -->
				</footer>
	
				<div class="comment-content"><p>飘～～</p>
</div>
				
			</article><!-- #comment-## -->
		</li>
		<li class="comment even thread-odd thread-alt depth-1" id="li-comment-46274">
			<article id="comment-46274" class="comment">
				<footer class="comment-meta">
					<cite class="comment-author vcard">
						<span class="fn">Paul</span> on <a rel="nofollow" href="http://livesino.net/about#comment-46274"><time pubdate datetime="2012-03-18T13:28:18+00:00">2012 年 03 月 18 日 at 1:28 下午</time></a> <span class="says">said:</span>					</cite><!-- .comment-author .vcard -->
				</footer>
	
				<div class="comment-content"><p>很喜欢这个网站，使我了解微软的重要入口，谢谢</p>
</div>
				
			</article><!-- #comment-## -->
		<ul class='children'>
		<li class="comment odd alt depth-2" id="li-comment-46278">
			<article id="comment-46278" class="comment">
				<footer class="comment-meta">
					<cite class="comment-author vcard">
						<span class="fn">leetom</span> on <a rel="nofollow" href="http://livesino.net/about#comment-46278"><time pubdate datetime="2012-03-19T12:25:37+00:00">2012 年 03 月 19 日 at 12:25 下午</time></a> <span class="says">said:</span>					</cite><!-- .comment-author .vcard -->
				</footer>
	
				<div class="comment-content"><p><a href="#comment-46274" rel="nofollow">@Paul</a> 是的，大家都这么觉得呢。我们感谢Picturepan2！</p>
</div>
				
			</article><!-- #comment-## -->
		</li>
</ul>
</li>
		<li class="comment even thread-even depth-1" id="li-comment-46637">
			<article id="comment-46637" class="comment">
				<footer class="comment-meta">
					<cite class="comment-author vcard">
						<span class="fn"><a href='http://ctwz.us' rel='external nofollow' class='url'>CT</a></span> on <a rel="nofollow" href="http://livesino.net/about#comment-46637"><time pubdate datetime="2012-04-12T13:07:58+00:00">2012 年 04 月 12 日 at 1:07 下午</time></a> <span class="says">said:</span>					</cite><!-- .comment-author .vcard -->
				</footer>
	
				<div class="comment-content"><p>首页顶部的分类导航怎么实现呢？</p>
</div>
				
			</article><!-- #comment-## -->
		</li>
		<li class="comment odd alt thread-odd thread-alt depth-1" id="li-comment-47509">
			<article id="comment-47509" class="comment">
				<footer class="comment-meta">
					<cite class="comment-author vcard">
						<span class="fn"><a href='http://yusky.me' rel='external nofollow' class='url'>Yusky</a></span> on <a rel="nofollow" href="http://livesino.net/about#comment-47509"><time pubdate datetime="2012-05-25T04:05:47+00:00">2012 年 05 月 25 日 at 4:05 上午</time></a> <span class="says">said:</span>					</cite><!-- .comment-author .vcard -->
				</footer>
	
				<div class="comment-content"><p>第一次来。 不过已经喜欢上。 嘿嘿</p>
</div>
				
			</article><!-- #comment-## -->
		</li>
		<li class="comment even thread-even depth-1" id="li-comment-47800">
			<article id="comment-47800" class="comment">
				<footer class="comment-meta">
					<cite class="comment-author vcard">
						<span class="fn"><a href='http://htmmt.com' rel='external nofollow' class='url'>意大利面</a></span> on <a rel="nofollow" href="http://livesino.net/about#comment-47800"><time pubdate datetime="2012-06-12T02:36:37+00:00">2012 年 06 月 12 日 at 2:36 上午</time></a> <span class="says">said:</span>					</cite><!-- .comment-author .vcard -->
				</footer>
	
				<div class="comment-content"><p>这个主题真是越做越精致~~   粉喜欢！</p>
</div>
				
			</article><!-- #comment-## -->
		</li>
		<li class="comment odd alt thread-odd thread-alt depth-1" id="li-comment-49643">
			<article id="comment-49643" class="comment">
				<footer class="comment-meta">
					<cite class="comment-author vcard">
						<span class="fn">onret</span> on <a rel="nofollow" href="http://livesino.net/about#comment-49643"><time pubdate datetime="2012-09-02T18:14:10+00:00">2012 年 09 月 2 日 at 6:14 下午</time></a> <span class="says">said:</span>					</cite><!-- .comment-author .vcard -->
				</footer>
	
				<div class="comment-content"><p>不知道新主题会放出来么？  </p>
</div>
				
			</article><!-- #comment-## -->
		</li>
		<li class="comment even thread-even depth-1" id="li-comment-49921">
			<article id="comment-49921" class="comment">
				<footer class="comment-meta">
					<cite class="comment-author vcard">
						<span class="fn"><a href='http://qingyang.me/' rel='external nofollow' class='url'>晴颺</a></span> on <a rel="nofollow" href="http://livesino.net/about#comment-49921"><time pubdate datetime="2012-09-11T20:00:01+00:00">2012 年 09 月 11 日 at 8:00 下午</time></a> <span class="says">said:</span>					</cite><!-- .comment-author .vcard -->
				</footer>
	
				<div class="comment-content"><p>这么久以来，我一直在纳闷，为什么广告栏上只有广告二字，却没有显示广告。今天才意识到广告被Chrome插件屏蔽了。。。  </p>
</div>
				
			</article><!-- #comment-## -->
		</li>
		<li class="comment odd alt thread-odd thread-alt depth-1" id="li-comment-50541">
			<article id="comment-50541" class="comment">
				<footer class="comment-meta">
					<cite class="comment-author vcard">
						<span class="fn"><a href='http://www.tengfeisite.info' rel='external nofollow' class='url'>TF</a></span> on <a rel="nofollow" href="http://livesino.net/about#comment-50541"><time pubdate datetime="2012-09-26T15:33:28+00:00">2012 年 09 月 26 日 at 3:33 下午</time></a> <span class="says">said:</span>					</cite><!-- .comment-author .vcard -->
				</footer>
	
				<div class="comment-content"><p>Thea这个主题很不错，不过觉得文章列表页那个评论数的背景图可以换成Windows Phone里短信的那个小框框。</p>
</div>
				
			</article><!-- #comment-## -->
		</li>
		<li class="comment even thread-even depth-1" id="li-comment-52102">
			<article id="comment-52102" class="comment">
				<footer class="comment-meta">
					<cite class="comment-author vcard">
						<span class="fn">ck</span> on <a rel="nofollow" href="http://livesino.net/about#comment-52102"><time pubdate datetime="2012-11-26T20:14:26+00:00">2012 年 11 月 26 日 at 8:14 下午</time></a> <span class="says">said:</span>					</cite><!-- .comment-author .vcard -->
				</footer>
	
				<div class="comment-content"><p>这个纯白主题挺不错，能提供下载么。。。</p>
</div>
				
			</article><!-- #comment-## -->
		</li>
		<li class="comment odd alt thread-odd thread-alt depth-1" id="li-comment-52325">
			<article id="comment-52325" class="comment">
				<footer class="comment-meta">
					<cite class="comment-author vcard">
						<span class="fn"><a href='http://www.isoftee.com/' rel='external nofollow' class='url'>爱软E</a></span> on <a rel="nofollow" href="http://livesino.net/about#comment-52325"><time pubdate datetime="2012-12-07T17:39:02+00:00">2012 年 12 月 7 日 at 5:39 下午</time></a> <span class="says">said:</span>					</cite><!-- .comment-author .vcard -->
				</footer>
	
				<div class="comment-content"><p>可以和贵站换个友联吗？爱软E科技博客</p>
</div>
				
			</article><!-- #comment-## -->
		</li>
		<li class="comment even thread-even depth-1" id="li-comment-52589">
			<article id="comment-52589" class="comment">
				<footer class="comment-meta">
					<cite class="comment-author vcard">
						<span class="fn"><a href='http://weibo.com/jimmyzerol' rel='external nofollow' class='url'>JimmyRespawn</a></span> on <a rel="nofollow" href="http://livesino.net/about#comment-52589"><time pubdate datetime="2012-12-17T19:29:59+00:00">2012 年 12 月 17 日 at 7:29 下午</time></a> <span class="says">said:</span>					</cite><!-- .comment-author .vcard -->
				</footer>
	
				<div class="comment-content"><p>网站做的很漂亮！而且还免费提供。</p>
</div>
				
			</article><!-- #comment-## -->
		</li>
		<li class="comment odd alt thread-odd thread-alt depth-1" id="li-comment-52783">
			<article id="comment-52783" class="comment">
				<footer class="comment-meta">
					<cite class="comment-author vcard">
						<span class="fn">李</span> on <a rel="nofollow" href="http://livesino.net/about#comment-52783"><time pubdate datetime="2012-12-25T21:09:57+00:00">2012 年 12 月 25 日 at 9:09 下午</time></a> <span class="says">said:</span>					</cite><!-- .comment-author .vcard -->
				</footer>
	
				<div class="comment-content"><p>你好。我的账号被盗用。怎么办？</p>
</div>
				
			</article><!-- #comment-## -->
		</li>
		<li class="comment even thread-even depth-1" id="li-comment-53656">
			<article id="comment-53656" class="comment">
				<footer class="comment-meta">
					<cite class="comment-author vcard">
						<span class="fn"><a href='http://www.ipc68.com' rel='external nofollow' class='url'>ipc68.com</a></span> on <a rel="nofollow" href="http://livesino.net/about#comment-53656"><time pubdate datetime="2013-02-24T16:49:01+00:00">2013 年 02 月 24 日 at 4:49 下午</time></a> <span class="says">said:</span>					</cite><!-- .comment-author .vcard -->
				</footer>
	
				<div class="comment-content"><p>不错的网站！~~</p>
</div>
				
			</article><!-- #comment-## -->
		</li>
		<li class="comment odd alt thread-odd thread-alt depth-1" id="li-comment-53705">
			<article id="comment-53705" class="comment">
				<footer class="comment-meta">
					<cite class="comment-author vcard">
						<span class="fn"><a href='http://www.qiuqiushi.com' rel='external nofollow' class='url'>糗糗事</a></span> on <a rel="nofollow" href="http://livesino.net/about#comment-53705"><time pubdate datetime="2013-02-28T14:11:56+00:00">2013 年 02 月 28 日 at 2:11 下午</time></a> <span class="says">said:</span>					</cite><!-- .comment-author .vcard -->
				</footer>
	
				<div class="comment-content"><p>主题很简洁，比较喜欢这种风格</p>
</div>
				
			</article><!-- #comment-## -->
		</li>
            </ol>

		            
    </div>			<div class="ads page-ads right pr"><div class="ads-tag pa">广告</div>
	<script type="text/javascript">google_ad_client="ca-pub-2225124559530218";google_ad_slot="9894180784";google_ad_width=728;google_ad_height=90;</script>
	<script type="text/javascript" src="http://pagead2.googlesyndication.com/pagead/show_ads.js"></script>
	</div></div>
	<div class="clear"></div>
	<div id="ntbox-ori">
		<div id="search" class="metrobox pr hide">
			<div class="metroboxt left">搜索</div>
			<div class="ntbox left"><form method="get" class="form-search" name="searchform" action="/index.php">
<input type="text" class="search-input left" size="24" value="" name="s"/>
<input type="submit" class="search-submit right fn-ti controls" value=""/>
</form></div>
			<a href="#" class="btn-close pa nav-btn right close">X</a>
		</div>
		<div id="contact" class="metrobox pr hide">
			<div class="metroboxt left">联系</div>
			<div class="ntbox left">
				<ul class="navs left">
					<li style="background-color:#E63B3F;"><a href="http://weibo.com/picturepan2" target="_blank" class="slim-btn block">新浪微博</a></li>
					<li style="background-color:#0FA1B8;"><a href="http://www.twitter.com/picturepan2" target="_blank" class="slim-btn block">Twitter</a></li>
					<li style="background-color:#0354A4;"><a href="mailto:picturepan2@livesino.net" class="slim-btn block">电子邮件</a></li>
				</ul>
			</div>
			<a href="#" class="btn-close pa nav-btn right close">X</a>
		</div>
		<div id="feed" class="metrobox pr hide">
			<div class="metroboxt left">订阅</div>
			<div class="ntbox left">
				<ul class="navs left">
					<li style="background-color:#4285F4;"><a href="http://fusion.google.com/add?feedurl=http://feed.livesino.net" target="_blank" class="slim-btn block">Google</a></li>
					<li style="background-color:#239FDB;"><a href="http://mail.qq.com/cgi-bin/feed?u=feed.livesino.net" target="_blank" class="slim-btn block">QQ</a></li>
					<li style="background-color:#EC2126;"><a href="http://reader.youdao.com/#url=http://feed.livesino.net" target="_blank" class="slim-btn block">有道</a></li>
					
					<li style="background-color:#F74419;"><a href="http://www.xianguo.com/subscribe.php?url=http://feed.livesino.net" target="_blank" class="slim-btn block">鲜果</a></li>
					<li style="background-color:#1C8D35;"><a href="http://9.douban.com/reader/subscribe?url=http://feed.livesino.net" target="_blank" class="slim-btn block">豆瓣</a></li>
					<li style="background-color:#666;"><a href="http://feed.livesino.net" target="_blank" class="slim-btn block">…</a></li>
				</ul>
			</div>
			<a href="#" class="btn-close pa nav-btn right close">X</a>
		</div>
		<div id="ie6" class="metrobox pr hide">
			<div class="left">
			<p>您正在使用 IE 6 浏览器访问本博客。简单几步，您就可以升级：<a href="http://windows.microsoft.com/zh-cn/internet-explorer/downloads/ie" target="_blank" rel="nofollow">Internet Explorer</a></p>
			</div>
			<a href="#" class="btn-close pa nav-btn right close">X</a>
		</div>
		<div id="MicrosoftTranslatorWidget" class="hide" style="border-color:#362F2A;background-color:#362F2A;"></div>
	</div>
</div>
<div id="footer" class="clear">
	<div class="legal wrapper">
		<div class="ntbox-1 left">
		<p><a href="/about">关于</a> <span class="sep">|</span> <a href="/about" title="爆料、合作或任何问题">联系</a> <span class="sep">|</span> <a href="/dev/resize.html">Resize</a> <span class="sep">|</span> <a href="/about" title="Theme Codename Thea" style="color:#d13b00;">Thea</a> <span class="sep">|</span> <a href="http://www.wordpress.org/" title="Powered by WordPress" style="color:#d13b00;" target="_blank">WordPress</a> <span class="sep">|</span> <a href="http://www.linode.com/?r=7cc63de94db4122770dd534665dc7bab347db167" title="Hosted by Linode" style="color:#d13b00;" target="_blank">Linode</a></p>
		<p>&copy; 2007 - 2013 LiveSino 保留一切权利 <span style="font-family:'Segoe UI Symbol';">&#128151;</span></p>
				</div>
		<div class="right"><p><a href="http://livesino.net/wp-login.php">登录</a> </p></div>
	</div>
</div>
<!--/livesino -->
<script type="text/javascript" src="/wp-content/themes/thea/core/jquery.colorbox.js"></script>
<script type="text/javascript">var _gaq=_gaq||[];_gaq.push(['_setAccount','UA-2702768-6']);_gaq.push(['_trackPageview']);(function(){var ga=document.createElement('script');ga.type='text/javascript';ga.async=true;ga.src=('https:'==document.location.protocol?'https://ssl':'http://www')+'.google-analytics.com/ga.js';var s=document.getElementsByTagName('script')[0];s.parentNode.insertBefore(ga,s);})();</script>

<p style="margin:0;padding:0;height:1px;overflow:hidden;">
    <script type="text/javascript">var wumiiSitePrefix="http://livesino.net";var wumiiEnableCustomPos=true;var wumiiParams="&num=6&mode=3&displayInFeed=1&version=1.0.5.5&pf=WordPress3.5";</script><script type="text/javascript" src="http://widget.wumii.com/ext/relatedItemsWidget.htm"></script><a href="http://www.wumii.com/widget/relatedItems.htm" style="border:0;"><img src="http://static.wumii.com/images/pixel.png" alt="无觅相关文章插件，快速提升流量" style="border:0;padding:0;margin:0;"/></a>
</p></body>
</html>
<!-- Performance optimized by W3 Total Cache. Learn more: http://www.w3-edge.com/wordpress-plugins/

Page Caching using apc
Object Caching 680/722 objects using apc

Served from: livesino.net @ 2013-03-05 14:02:04 -->