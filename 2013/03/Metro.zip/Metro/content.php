		<div class="post" id="post-<?php the_ID(); ?>">
		<div class="entry-head clear"><h2 class="left"><a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2><div class="post-cmt block pr right"><a href="<?php the_permalink(); ?>#respond" title="《<?php the_title(); ?>》上的评论"><span class="ds-thread-count" data-thread-key="<?php the_ID(); ?>" data-replace="1">0</span></a><span class="corner pa"></span></div></div>
		<div class="entry clear">
			<span class="post-meta"><?php echo date("Y年m月d日 H:i:s",get_the_time('U')); ?> - <?php the_author(); ?> <?php if(is_user_logged_in()) edit_post_link();?> </span>
			<span class="post-love"></span>
            <?php
	            if (is_search()) {
	                the_excerpt();
	                //echo '<p><a href="http://localhost/?p=2140#more-2140" class="more-link">阅读全文</a></p>';
	            }else{
	                the_content('阅读全文');
	            }
            ?>
		</div>
	</div>