/* 全局设置 */
var burl="http://www.xiumu.org/wp-content/themes/blog_v3/script/pop/"; //附件目录
/* 主文件 */
-function(){
	var d=document,
		isStrict=d.compatMode=="CSS1Compat",
		dd=d.documentElement,
		db=d.body,
		m=Math.max,
		na=navigator.userAgent.toLowerCase(),
		ie=!!d.all,
		head=d.getElementsByTagName('head')[0],
		getWH=function()
		{
			return{ 
			h:(isStrict?dd:db).clientHeight,
			w:(isStrict?dd:db).clientWidth}
		},
		getS=function()	{
			return	{
			t:m(dd.scrollTop,db.scrollTop),l:m(dd.scrollLeft,db.scrollLeft)
			}
		}
		,creElm=function(o,t,a){
			var b=d.createElement(t||'div');
			for(var p in o)	{
				p=='style'?b[p].cssText=o[p]:b[p]=o[p]
			}
			return(a||db).insertBefore(b,(a||db).firstChild)
		}
	,div,div1=creElm({id:'ckepop',style:"height:auto;position:absolute;z-index:100000;display:none;top:50%;left:50%;overflow:auto;"}),
	inputTimer,list,clist,as,texts={},script,timerover,timerout,timerloop,
	loop=function(){var t=1000,st=getS().t,c,wh=getWH();c=st-div.offsetTop+(wh.h/2-$CKE.pop.offsetWidth/2);c!=0&&(div.style.top=div.offsetTop+c/10+'px',t=10);timerloop=setTimeout(loop,t)
	}
	,iframe=creElm({style:'position:'+(/firefox/.test(na)?'fixed':'absolute')+';display:none;',frameBorder:0},'iframe'),
	conf={type:'right',move:'roll'},
	scripts=d.getElementsByTagName('script');
		for(var i=0,ci;ci=scripts[i++];){
		if(/jiathis/.test(ci.src)){
			ci.src.replace(/(type|btn|move)=([^&]+)/g,function(a,p,v){conf[p]=v})
			}
		};
div=creElm({
	id:'ckepop',
	style:"height:auto;position:"+(conf.move=='roll'||/msie 6/i.test(na)?'absolute':'fixed')+";z-index:100000000;top:"+(conf.move=='roll'||/msie 6/i.test(na)?'0':'150px')+";"+(conf.type=='right'?"right:0;overflow:hidden;width:26px;":"left:-242px;overflow:auto;"),
	//innerHTML:conf.type=='right'?"<table cellPadding=0 cellSpacing=0 ><tbody style='background:transparent'><tr><td style='background:transparent' ><img id='jiathis_a'src="+burl+"r.png style='cursor:pointer;' onmouseover='$CKE.over()' onclick='popCoverDiv();$CKE.center(this)'/></td><td><div ></div></td></tr></tbody></table>":"<table cellPadding=0 cellSpacing=0 ><tbody style='background:transparent'><tr><td><div ></div></td><td><img id='jiathis_a'src="+burl+"r.png style='cursor:pointer;' onmouseover='$CKE.over()' onclick='$CKE.center(this)'/></td></tr></tbody></table>"
	innerHTML:conf.type=='right'?"<table cellPadding=0 cellSpacing=0 ><tbody style='background:transparent'><tr><td style='background:transparent' ><img id='jiathis_a'src="+burl+"r.png style='cursor:pointer;' onclick='popCoverDiv();$CKE.center(this)'/></td><td><div ></div></td></tr></tbody></table>":"<table cellPadding=0 cellSpacing=0 ><tbody style='background:transparent'><tr><td><div ></div></td><td><img id='jiathis_a'src="+burl+"r.png style='cursor:pointer;' onclick='popCoverDiv();$CKE.center(this)'/></td></tr></tbody></table>"
});
	creElm({href:''+burl+'style.css',rel:'stylesheet',type:'text/css'},'link');
	/*d.write('<script src="ckepop.js" charset="utf-8"></script><script src="ckecenterpop.js" charset="utf-8"></script>');*/
	$CKE={pop:div.getElementsByTagName('div')[0],
		centerpop:div1,
		disappear:function(a){
		var b=window.event||a,t=b.srcElement||b.target,contain=div1.contains?div1.contains(t):!!(div1.compareDocumentPosition(t)&16),contain1=div.contains?div.contains(t):!!(div.compareDocumentPosition(t)&16);
		if(!contain&&!contain1){
			iframe.style.display=div1.style.display='none';
			/*清除背景*/
			cancelSign();
		}
		},
	over:conf.type=='right'?function(){
	if (div.offsetWidth>26) return;
	clearTimeout(timerloop);
	clearInterval(timerout);
	div.style.cssText+=";height:"+this.pop.offsetHeight+"px;width:26px;left:"+(getWH()-26)+"px";
	var t=10,tmp=0,step=this.pop.offsetWidth/55;
	timerover=setInterval (
		function(){
			if(t==0){clearInterval(timerover);(conf.move=='roll'||/msie 6/i.test(na))&&loop()}else{var n=Math.round(step*t--);div.style.left=div.offsetLeft-n+'px';div.style.width=div.offsetWidth+n+'px'}
			},10)
	}
	
	:function(){
	clearTimeout(timerloop);clearInterval(timerout);clearInterval(timerover);var t=10,tmp=0,step=Math.abs(div.offsetLeft/55);timerover=setInterval(function(){if(t==0){clearInterval(timerover);(conf.move=='roll'||/msie 6/i.test(na))&&loop()}else{var n=Math.round(step*t--);div.style.left=div.offsetLeft+n+'px'}},10)
	}
	,out:conf.type=='right'?function(){
	if(div.offsetWidth>$CKE.pop.offsetWidth){
		clearInterval(timerover);
		clearTimeout(timerloop);
		div.style.cssText+=";height:"+$CKE.pop.offsetHeight+"px;width:"+($CKE.pop.offsetWidth+26)+"px;left:"+(getWH()-26-$CKE.pop.offsetWidth)+"px";var t=10,tmp=0,step=(div.offsetWidth-26)/55;timerout=setInterval(function(){if(t==0){clearInterval(timerout);div.style.left='';(conf.move=='roll'||/msie 6/i.test(na))&&loop()
		}
		else{
		var n=Math.round(step*t--);
		div.style.width=div.offsetWidth-n<26?26:div.offsetWidth-n+'px';
		div.style.left=div.offsetLeft+n+'px'}},10)
		}
	}
	:function(){
	clearInterval(timerover);clearInterval(timerout);clearTimeout(timerloop);var t=10,tmp=0,step=Math.abs((div.offsetLeft+242)/55);timerout=setInterval(function(){if(t==0){clearInterval(timerout);div.style.left='-242px';(conf.move=='roll'||/msie 6/i.test(na))&&loop()}else{var n=Math.round(step*t--);div.style.left=div.offsetLeft-n+'px'}},10)
	}
	,center:function(a){
		if(a){
			db.style.position='static';
			var b=getS();
			div1.style.display="block";
			div1.style.margin=(-div1.offsetHeight/2+b.t)+"px "+(-div1.offsetWidth/2+b.l)+"px";
			list=d.getElementById('ckelist');
			clist=list.cloneNode(true);as=clist.getElementsByTagName('input');
			for(var i=0,ci;ci=as[i++];){
				texts[ci.value]=ci.parentNode
			};
			with(iframe.style){
				left=top='50%';
				width=div1.offsetWidth+'px';
				height=div1.offsetHeight+'px';
				margin=div1.style.margin;display='block'
			}
		}
	}
	,choose:function(o){clearTimeout(inputTimer);inputTimer=setTimeout(function(){var s=o.value.replace(/^\s+|\s+$/,''),frag=d.createDocumentFragment();for(var p in texts){eval("var f = /"+(s||'.')+"/ig.test(p)");f&&frag.appendChild(texts[p].cloneNode(true))}list.innerHTML='';
	list.appendChild(frag)},100)}
	,centerClose:function(){iframe.style.display=div1.style.display='none'}
	};
	if(ie){
	div.onmouseleave=$CKE.out;d.attachEvent("onclick",$CKE.disappear)
	}
	else{
	div.onmouseout=function(e){!(this===e.relatedTarget||(this.contains?this.contains(e.relatedTarget):this.compareDocumentPosition(e.relatedTarget)==20))&&$CKE.out.call(this)};d.addEventListener("click",$CKE.disappear,false)
	};
	(conf.move=='roll'||/msie 6/i.test(na))&&loop()
}();

function jiathis_sendto(a){
	var e=encodeURIComponent,conf;try{conf=jiathis_config}catch(err){conf={}};
	window.open('http://www.jiathis.com/send/?webid='+a+'&url='+e(conf.url||location)+'&title='+e(conf.title||document.title)+(conf.un?'&un='+conf.un:''),'');
	return false
};

function jt_copyUrl(){var a=this.location.href;var b=document.title;
	if(window.clipboardData){var c=b+"\n"+a;var d=window.clipboardData.setData("Text",c);
	if(d)alert("复制成功,请粘贴到你的QQ/MSN上推荐给你的好友！")
	}
	else{alert("目前只支持IE，请复制地址栏URL,推荐给你的QQ/MSN好友！")}
};

function jt_addBookmark(a){
	var b=parent.location.href;
	if(window.sidebar){
	window.sidebar.addPanel(a,b,"")
	}
	else if(document.all){
	window.external.AddFavorite(b,a)
	}
	else if(window.opera&&window.print){return true}
}

/* 滑动层 */
setTimeout(function(){
	$CKE.pop.innerHTML = '<div class="jiadiv_01" > \
		<div style=" background:#F2F2F2;border-bottom:1px solid #E5E5E5;line-height:200%;padding-left:5px;font-size:12px"><b>分享到...</b><\/div> \
		<div class="jiadiv_02"> \
			<a href="#" onclick="jt_copyUrl();return false;" class="jiatitle"><span class="jtico jtico_copy">复制网址</span><input type="hidden" value="复制fz" /></a>\
			<a href="#" onclick="jt_addBookmark(document.title);return false;" class="jiatitle"><span class="jtico jtico_fav">收藏夹</span><input type="hidden" value="收藏夹scj" /></a>\
			<a href="#" onclick="javascript:window.print();return false;" class="jiatitle"><span class="jtico jtico_print">打印</span><input type="hidden" value="打印dy" /></a>\
			<a href="#" onclick="jiathis_sendto(\'google\');return false;" class="jiatitle"><span class="jtico jtico_google">Google</span><input type="hidden" value="Google" /></a>\
			<a href="#" onclick="jiathis_sendto(\'baidu\');return false;" class="jiatitle"><span class="jtico jtico_baidu">百度收藏</span><input type="hidden" value="百度baidu" /></a>\
			<a href="#" onclick="jiathis_sendto(\'qq\');return false;" class="jiatitle"><span class="jtico jtico_qq">QQ书签</span><input type="hidden" value="qq" /></a>\
			<a href="#" onclick="jiathis_sendto(\'tsina\');return false;" class="jiatitle"><span class="jtico jtico_tsina">新浪微博</span><input type="hidden" value="SINA微博wb" /></a>\
			<a href="#" onclick="jiathis_sendto(\'sohu\');return false;" class="jiatitle"><span class="jtico jtico_sohu">搜狐白社会</span><input type="hidden" value="搜狐sohu" /></a>\
			<a href="#" onclick="jiathis_sendto(\'renren\');return false;" class="jiatitle"><span class="jtico jtico_renren">人人网</span><input type="hidden" value="人人renren" /></a>\
			<a href="#" onclick="jiathis_sendto(\'kaixin001\');return false;" class="jiatitle"><span class="jtico jtico_kaixin001">开心网</span><input type="hidden" value="开心网kaixin" /></a>\
			<a href="#" onclick="jiathis_sendto(\'gmail\');return false;" class="jiatitle"><span class="jtico jtico_gmail">Gmail</span><input type="hidden" value="gmail" /></a>\
 			<a href="#" onclick="jiathis_sendto(\'tongxue\');return false;" class="jiatitle"><span class="jtico jtico_tongxue">同学微博</span><input type="hidden" value="同学tongxue" /></a>\
			<a href="#" onclick="jiathis_sendto(\'zhuaxia\');return false;" class="jiatitle"><span class="jtico jtico_zhuaxia">抓虾</span><input type="hidden" value="抓虾ZX" /></a>\
			<a href="#" onclick="jiathis_sendto(\'douban\');return false;" class="jiatitle"><span class="jtico jtico_douban">豆瓣</span><input type="hidden" value="豆瓣db" /></a>\
			<a href="#" onclick="jiathis_sendto(\'digu\');return false;" class="jiatitle"><span class="jtico jtico_digu">嘀咕</span><input type="hidden" value="嘀咕digu" /></a>\
			<a href="#" onclick="$CKE.center(this);return false;" class="jiatitle"><span class="jtico jtico_more" >查看更多(58)</span><input type="hidden" value="更多gd" /></a>\
			<div style="clear:both"></div>\
		<\/div> \
		<div style="background:#F2F2F2;border-top:1px solid #E5E5E5;line-height:120%;padding-left:5px;"> \
			<div style="width:120px;float:left;font-size:10px"></div> \
			<div style="width:80px;float:right;font-size:11px"></div> \
			<div style="clear:both"></div> \
		</div> \
	</div>'
//$CKE.over();
},0)

/* 弹出层 */
-function(){
	$CKE.centerpop.innerHTML = '<div style="border:10px solid #050505; width:300px;background:url('+burl+'bg.png);">\
		<div class="jiadiv_01" style="width:300px;">\
			<div style="background:url('+burl+'bg_black.png);line-height:200%;padding-left:5px;">\
				<div style="font-weight:bold;font-size:12px;float:left;color:#3399FF;">分享到各大网站</div>\
				<div style="float:right"><img src="'+burl+'exit.png" border="0" style="margin:4px 4px 0 0;cursor:pointer;" onclick="cancelSign();$CKE.centerClose()"/></div>\
				<div style="clear:both;height:0;"></div>\
			</div>\
			<div style=" border-bottom:2px solid #111;padding-left:5px;">\
				<div style="background:url('+burl+'img_so.png) no-repeat center;height:30px; width:281px">\
					<input name="" type="text" onclick="this.value=\'\'" value="输入网站名或拼音缩写" style="background:none;border:none;margin:7px 0 0 28px;width:240px;height:15px;color:#3399FF;" onkeyup = "$CKE.choose(this)" />\
				</div>\
			</div>\
			<div id="ckelist" class="jiadiv_02" style="height:300px;overflow-y:auto;scrollbar-face-color: #333333; scrollbar-shadow-color: #333333; scrollbar-highlight-color: #666666; scrollbar-3dlight-color: #101010; scrollbar-darkshadow-color: #070707; scrollbar-track-color: #101010; scrollbar-arrow-color: #000000;">\
<a href="#" onclick="jt_copyUrl();return false;" class="jiatitle"><span class="jtico jtico_copy">复制网址</span><input type="hidden" value="复制fz" /></a>\
<a href="#" onclick="jt_addBookmark(document.title);return false;" class="jiatitle"><span class="jtico jtico_fav">收藏夹</span><input type="hidden" value="收藏夹scj" /></a>\
<a href="#" onclick="javascript:window.print();return false;" class="jiatitle"><span class="jtico jtico_print">打印</span><input type="hidden" value="打印dy" /></a>\
<a href="#" onclick="jiathis_sendto(\'google\');return false;" class="jiatitle"><span class="jtico jtico_google">Google</span><input type="hidden" value="Google" /></a>\
<a href="#" onclick="jiathis_sendto(\'baidu\');return false;" class="jiatitle"><span class="jtico jtico_baidu">百度收藏</span><input type="hidden" value="百度baidu" /></a>\
<a href="#" onclick="jiathis_sendto(\'qq\');return false;" class="jiatitle"><span class="jtico jtico_qq">QQ书签</span><input type="hidden" value="qq" /></a>\
<a href="#" onclick="jiathis_sendto(\'tsina\');return false;" class="jiatitle"><span class="jtico jtico_tsina">新浪微博</span><input type="hidden" value="SINA微博wb" /></a>\
<a href="#" onclick="jiathis_sendto(\'sohu\');return false;" class="jiatitle"><span class="jtico jtico_sohu">搜狐白社会</span><input type="hidden" value="搜狐sohu" /></a>\
<a href="#" onclick="jiathis_sendto(\'renren\');return false;" class="jiatitle"><span class="jtico jtico_renren">人人网</span><input type="hidden" value="人人renren" /></a>\
<a href="#" onclick="jiathis_sendto(\'kaixin001\');return false;" class="jiatitle"><span class="jtico jtico_kaixin001">开心网</span><input type="hidden" value="开心网kaixin" /></a>\
<a href="#" onclick="jiathis_sendto(\'gmail\');return false;" class="jiatitle"><span class="jtico jtico_gmail">Gmail</span><input type="hidden" value="gmail" /></a>\
<a href="#" onclick="jiathis_sendto(\'hotmail\');return false;" class="jiatitle"><span class="jtico jtico_hotmail">Hotmail</span><input type="hidden" value="hotmail" /></a>\
<a href="#" onclick="jiathis_sendto(\'sina\');return false;" class="jiatitle"><span class="jtico jtico_sina">新浪收藏</span><input type="hidden" value="新浪sina" /></a>\
<a href="#" onclick="jiathis_sendto(\'live\');return false;" class="jiatitle"><span class="jtico jtico_live">Live收藏</span><input type="hidden" value="live" /></a>\
<a href="#" onclick="jiathis_sendto(\'yahoo\');return false;" class="jiatitle"><span class="jtico jtico_yahoo">Yahoo收藏</span><input type="hidden" value="Yahoo" /></a>\
<a href="#" onclick="jiathis_sendto(\'delicious\');return false;" class="jiatitle"><span class="jtico jtico_delicious">Delicious</span><input type="hidden" value="Delicious" /></a>\
<a href="#" onclick="jiathis_sendto(\'digg\');return false;" class="jiatitle"><span class="jtico jtico_digg">Digg </span><input type="hidden" value="Digg" /></a>\
<a href="#" onclick="jiathis_sendto(\'fb\');return false;" class="jiatitle"><span class="jtico jtico_fb">Facebook</span><input type="hidden" value="Facebook" /></a>\
<a href="#" onclick="jiathis_sendto(\'twitter\');return false;" class="jiatitle"><span class="jtico jtico_twitter">Twitter</span><input type="hidden" value="Twitter" /></a>\
<a href="#" onclick="jiathis_sendto(\'myspace\');return false;" class="jiatitle"><span class="jtico jtico_myspace">Myspace</span><input type="hidden" value="myspace" /></a>\
<a href="#" onclick="jiathis_sendto(\'taobao\');return false;" class="jiatitle"><span class="jtico jtico_taobao">淘宝网</span><input type="hidden" value="淘宝taobao" /></a>\
<a href="#" onclick="jiathis_sendto(\'jiwai\');return false;" class="jiatitle"><span class="jtico jtico_jiwai">叽歪</span><input type="hidden" value="叽歪jiwai" /></a>\
<a href="#" onclick="jiathis_sendto(\'digu\');return false;" class="jiatitle"><span class="jtico jtico_digu">嘀咕网</span><input type="hidden" value="嘀咕digu" /></a>\
<a href="#" onclick="jiathis_sendto(\'douban\');return false;" class="jiatitle"><span class="jtico jtico_douban">豆瓣 </span><input type="hidden" value="豆瓣douban" /></a>\
<a href="#" onclick="jiathis_sendto(\'zhuaxia\');return false;" class="jiatitle"><span class="jtico jtico_zhuaxia">抓虾</span><input type="hidden" value="抓虾zhuaxia" /></a>\
<a href="#" onclick="jiathis_sendto(\'xianguo\');return false;" class="jiatitle"><span class="jtico jtico_xianguo">鲜果</span><input type="hidden" value="鲜果xianguo" /></a>\
<a href="#" onclick="jiathis_sendto(\'zuosa\');return false;" class="jiatitle"><span class="jtico jtico_zuosa">做啥</span><input type="hidden" value="做啥zuosa" /></a>\
<a href="#" onclick="jiathis_sendto(\'renjian\');return false;" class="jiatitle"><span class="jtico jtico_renjian">人间</span><input type="hidden" value="人间renjian" /></a>\
<a href="#" onclick="jiathis_sendto(\'hexun\');return false;" class="jiatitle"><span class="jtico jtico_hexun">和讯收藏</span><input type="hidden" value="和讯hexun" /></a>\
<a href="#" onclick="jiathis_sendto(\'yesky\');return false;" class="jiatitle"><span class="jtico jtico_yesky">天极收藏</span><input type="hidden" value="天极yesky" /></a>\
<a href="#" onclick="jiathis_sendto(\'wong\');return false;" class="jiatitle"><span class="jtico jtico_wong">Mister Wong</span><input type="hidden" value="MisterWong" /></a>\
<a href="#" onclick="jiathis_sendto(\'poco\');return false;" class="jiatitle"><span class="jtico jtico_poco">POCO</span><input type="hidden" value="POCO" /></a>\
<a href="#" onclick="jiathis_sendto(\'365key\');return false;" class="jiatitle"><span class="jtico jtico_365key">天天网摘</span><input type="hidden" value="天天网摘365tt" /></a>\
<a href="#" onclick="jiathis_sendto(\'leshou\');return false;" class="jiatitle"><span class="jtico jtico_leshou">乐收网</span><input type="hidden" value="乐收leshou" /></a>\
<a href="#" onclick="jiathis_sendto(\'diglog\');return false;" class="jiatitle"><span class="jtico jtico_diglog">奇客发现</span><input type="hidden" value="奇客diglog" /></a>\
<a href="#" onclick="jiathis_sendto(\'tongxue\');return false;" class="jiatitle"><span class="jtico jtico_tongxue">同学微博</span><input type="hidden" value="同学tongxue" /></a>\
<a href="#" onclick="jiathis_sendto(\'waakee\');return false;" class="jiatitle"><span class="jtico jtico_waakee">挖客网</span><input type="hidden" value="挖客网waakee" /></a>\
<a href="#" onclick="jiathis_sendto(\'shouker\');return false;" class="jiatitle"><span class="jtico jtico_shouker">收客网</span><input type="hidden" value="收客网shouker" /></a>\
<a href="#" onclick="jiathis_sendto(\'9fav\');return false;" class="jiatitle"><span class="jtico jtico_9fav">就喜欢</span><input type="hidden" value="就喜欢9fav" /></a>\
<a href="#" onclick="jiathis_sendto(\'114la\');return false;" class="jiatitle"><span class="jtico jtico_114la">114啦</span><input type="hidden" value="114啦la" /></a>\
<a href="#" onclick="jiathis_sendto(\'115\');return false;" class="jiatitle"><span class="jtico jtico_115">115收藏</span><input type="hidden" value="115收藏" /></a>\
<a href="#" onclick="jiathis_sendto(\'follow5\');return false;" class="jiatitle"><span class="jtico jtico_follow5">5享网</span><input type="hidden" value="5享follow5" /></a>\
<a href="#" onclick="jiathis_sendto(\'amazon\');return false;" class="jiatitle"><span class="jtico jtico_amazon">Amazon</span><input type="hidden" value="amazon" /></a>\
<a href="#" onclick="jiathis_sendto(\'ask\');return false;" class="jiatitle"><span class="jtico jtico_ask">ASK</span><input type="hidden" value="ask" /></a>\
<a href="#" onclick="jiathis_sendto(\'diigo\');return false;" class="jiatitle"><span class="jtico jtico_diigo">DIIGO</span><input type="hidden" value="diigo" /></a>\
<a href="#" onclick="jiathis_sendto(\'evernote\');return false;" class="jiatitle"><span class="jtico jtico_evernote">Evernote笔记</span><input type="hidden" value="evernote" /></a>\
<a href="#" onclick="jiathis_sendto(\'friendfeed\');return false;" class="jiatitle"><span class="jtico jtico_friendfeed">FriendFeed</span><input type="hidden" value="friendfeed" /></a>\
<a href="#" onclick="jiathis_sendto(\'linkedin\');return false;" class="jiatitle"><span class="jtico jtico_linkedin">Linkedin商务</span><input type="hidden" value="linkedin" /></a>\
<a href="#" onclick="jiathis_sendto(\'mixx\');return false;" class="jiatitle"><span class="jtico jtico_mixx">MIXX</span><input type="hidden" value="mixx" /></a>\
<a href="#" onclick="jiathis_sendto(\'netlog\');return false;" class="jiatitle"><span class="jtico jtico_netlog">Netlog中文</span><input type="hidden" value="netlog" /></a>\
<a href="#" onclick="jiathis_sendto(\'netvibes\');return false;" class="jiatitle"><span class="jtico jtico_netvibes">Netvibes</span><input type="hidden" value="netvibes" /></a>\
<a href="#" onclick="jiathis_sendto(\'pdfonline\');return false;" class="jiatitle"><span class="jtico jtico_pdfonline">网页转PDF</span><input type="hidden" value="pdfonline" /></a>\
<a href="#" onclick="jiathis_sendto(\'phonefavs\');return false;" class="jiatitle"><span class="jtico jtico_phonefavs">Phone Favs</span><input type="hidden" value="phonefavs" /></a>\
<a href="#" onclick="jiathis_sendto(\'pingfm\');return false;" class="jiatitle"><span class="jtico jtico_pingfm">Ping.fm</span><input type="hidden" value="pingfm" /></a>\
<a href="#" onclick="jiathis_sendto(\'plaxo\');return false;" class="jiatitle"><span class="jtico jtico_plaxo">Plaxo</span><input type="hidden" value="plaxo" /></a>\
<a href="#" onclick="jiathis_sendto(\'polladium\');return false;" class="jiatitle"><span class="jtico jtico_polladium">Polladium投票</span><input type="hidden" value="polladium" /></a>\
<a href="#" onclick="jiathis_sendto(\'printfriendly\');return false;" class="jiatitle"><span class="jtico jtico_printfriendly">友好打印</span><input type="hidden" value="printfriendly" /></a>\
<a href="#" onclick="jiathis_sendto(\'reddit\');return false;" class="jiatitle"><span class="jtico jtico_reddit">Reddit</span><input type="hidden" value="reddit" /></a>\
<a href="#" onclick="jiathis_sendto(\'stumbleupon\');return false;" class="jiatitle"><span class="jtico jtico_stumbleupon">Stumbleupon</span><input type="hidden" value="stumbleupon" /></a>\
<a href="#" onclick="jiathis_sendto(\'translate\');return false;" class="jiatitle"><span class="jtico jtico_translate">翻译英文</span><input type="hidden" value="translate" /></a>\
<a href="#" onclick="jiathis_sendto(\'ymail\');return false;" class="jiatitle"><span class="jtico jtico_ymail">Yahoo! mail</span><input type="hidden" value="ymail" /></a>\
<div style="clear:both"></div>\
			</div>\
			<div style="border-top:2px solid #111;line-height:120%;padding-left:5px;">\
				<div style="width:120px;float:left;font-size:10px"></div>\
				<div style="width:80px;float:right;font-size:11px">\
				</div>\
				<div style="clear:both"></div>\
			</div>\
		</div>\
	</div></div>'
	$CKE.center();
}()



/*背景灰度*/
     function G(id){
       return document.getElementById(id);
     };
     
    function GC(t){
       return document.createElement(t);
    };
    
    String.prototype.trim = function(){
              return this.replace(/(^\s*)|(\s*$)/g, '');
    };
    
    function isIE(){
          return (document.all && window.ActiveXObject && !window.opera) ? true : false;
    }
    
    function getBodySize(){
           var bodySize = [];
        with(document.documentElement) {
         bodySize[0] = (scrollWidth>clientWidth)?scrollWidth:clientWidth;
         bodySize[1] = (scrollHeight>clientHeight)?scrollHeight:clientHeight;
        }
           return bodySize;
    }
 
    
  function popCoverDiv(){
   if (G("cover_div")) {
    G("cover_div").style.display = '';
   } else {
    var coverDiv = GC('div');
    document.body.appendChild(coverDiv);
    coverDiv.id = 'cover_div';
    
    with(coverDiv.style) {
     position = 'absolute';
     background = '#000';
     left = '0px';
     top = '0px';
     var bodySize = getBodySize();
     width = bodySize[0] + 'px'
     height = bodySize[1] + 'px';
     zIndex = 98;
     if (isIE()) {
      filter = "Alpha(Opacity=75)";
     } else {
      opacity = 0.6;
     }
    }
   }
}
/*清除背景*/
function cancelSign(){
    G("cover_div").style.display = 'none';
   document.body.style.overflow = '';
};