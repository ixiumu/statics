<?php
$theme_name = 'metro';
$theme_full_version = '2.2';
?>
